package softuni.models.entities.cores;

public class ParaCore extends AbstractCore {

    public ParaCore(Integer durability) {
        super(durability/3);
    }
}
