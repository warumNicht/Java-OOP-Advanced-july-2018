package softuni.models.entities.cores;

public class SystemCore extends AbstractCore{

    public SystemCore(Integer durability) {
        super(durability);
    }
}
