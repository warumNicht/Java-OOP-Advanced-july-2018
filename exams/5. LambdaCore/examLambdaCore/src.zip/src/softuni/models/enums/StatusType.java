package softuni.models.enums;

public enum StatusType {
    NORMAL,
    CRITICAL
}
