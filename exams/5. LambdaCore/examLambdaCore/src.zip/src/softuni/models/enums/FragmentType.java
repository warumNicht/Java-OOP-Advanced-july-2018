package softuni.models.enums;

public enum FragmentType {
    Nuclear,
    Cooling
}
