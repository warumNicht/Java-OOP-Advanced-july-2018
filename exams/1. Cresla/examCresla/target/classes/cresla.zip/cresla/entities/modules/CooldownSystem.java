package cresla.entities.modules;

public class CooldownSystem extends AbsorberModule {
    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }


}
