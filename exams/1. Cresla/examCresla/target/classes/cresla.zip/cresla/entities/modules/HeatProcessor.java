package cresla.entities.modules;

public class HeatProcessor extends AbsorberModule {
    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }

}
