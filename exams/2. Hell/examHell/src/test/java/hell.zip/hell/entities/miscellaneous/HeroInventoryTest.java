package hell.entities.miscellaneous;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HeroInventoryTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void getTotalStrengthBonus() {
    }

    @Test
    public void getTotalAgilityBonus() {
    }

    @Test
    public void getTotalIntelligenceBonus() {
    }

    @Test
    public void getTotalHitPointsBonus() {
    }

    @Test
    public void getTotalDamageBonus() {
    }

    @Test
    public void addCommonItem() {
    }

    @Test
    public void addRecipeItem() {
    }
}