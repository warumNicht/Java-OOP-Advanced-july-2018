package contracts;

import exeptions.DuplicateModelException;
import exeptions.NonExistantModelException;

import java.util.Map;

public interface CrudRepository<T extends Modelable> {
    T findByModel(String model) throws NonExistantModelException;

    void add(T item) throws DuplicateModelException;
}
