package contracts;

public interface InputReader {
    String readLine();
}
