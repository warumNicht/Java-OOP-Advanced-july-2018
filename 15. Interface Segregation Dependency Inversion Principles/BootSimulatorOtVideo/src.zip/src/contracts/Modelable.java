package contracts;

public interface Modelable {
    String getModel();
}
